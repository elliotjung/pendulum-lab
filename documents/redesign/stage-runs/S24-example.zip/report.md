# 이중진자 기록에서 검토 패키지까지

같은 물리 엔진으로 계산한 두 초기조건의 짧은 기록을 보존하고 원 run에서 그림과 보고서를 추적할 수 있는가?

Project: s24-example-project
Schema: pendulum-research-project/v1
Software: @elliotjung/pendulum-lab 10.36.0
Created: 2026-11-03T00:00:00.000Z
Updated: 2026-11-03T00:00:00.000Z

## 검증과 재현 범위

SHA-256은 패키지 내부 바이트의 무결성을 확인합니다. 외부 출처·과학적 정확성·사람 검토를 인증하지 않습니다.
원 run 설정·기록과 native 결과 파일을 보존합니다. 기록 캡처는 계산 checkpoint 재개 또는 모든 외부 환경의 bitwise 재현을 보장하지 않습니다.
원본 결과 JSON은 해당 Lab 도구에서 다시 열어 재계산·재평가할 수 있습니다. legacy 파일은 기존 앱에서 열며 opaque 첨부는 실행하지 않습니다.

## 세션과 run

### 두 초기조건의 기록 · s24-example-session

- 초기각 차이 0 rad · s24-example-run-0 · completed · 2026-11-03T00:00:00.000Z
  클릭 시점의 기록 표본 21개와 입력을 복사했습니다. 전체 궤적·새 계산·장기 재현성을 보장하지 않습니다.
  System system:double · model planar-model-v1 · seed \(없음\)
- 초기각 차이 0.001 rad · s24-example-run-1 · completed · 2026-11-03T00:00:00.000Z
  클릭 시점의 기록 표본 21개와 입력을 복사했습니다. 전체 궤적·새 계산·장기 재현성을 보장하지 않습니다.
  System system:double · model planar-model-v1 · seed \(없음\)

## Artifact와 누락 목록

- 보존됨: experiment.json · artifact-69d2a219ec924caf50dc5e67-0 · run s24-example-run-0
  schema pendulum-experiment/v1 · 1396 bytes · SHA-256 69d2a219ec924caf50dc5e679afbe0788988cd03b434b90e3c3e5371c0b139ac
  path artifacts/artifact-69d2a219ec924caf50dc5e67-0.json · parents (없음)
  캡처한 canonical 설정. SI 값·단위·seed·적분·model/schema version을 보존합니다.
- 보존됨: series.json · artifact-9e34ca15fd690c68204f5d49-1 · run s24-example-run-0
  schema pendulum-project-series/v1 · 5508 bytes · SHA-256 9e34ca15fd690c68204f5d49a54a68ae45dd694ac41cf74e53023870c950a720
  path artifacts/artifact-9e34ca15fd690c68204f5d49-1.json · parents artifact-69d2a219ec924caf50dc5e67-0
  실제 기록 표본을 순서·시간축·좌표·단위와 함께 복사했습니다. 보간·단위 재명명·재계산하지 않았습니다.
- 보존됨: energy-0.json · artifact-a4592ff6a9295abfd057726d-2 · run s24-example-run-0
  schema pendulum-core-diagnostic/v1 · 9085 bytes · SHA-256 a4592ff6a9295abfd057726d1297d587d404cd645ccad237d720da089cc13dbf
  path artifacts/artifact-a4592ff6a9295abfd057726d-2.json · parents artifact-9e34ca15fd690c68204f5d49-1
  보존한 원 기록에서 기존 native 에너지 분석을 실행했습니다. native input ID도 별도로 보존합니다.
  Native input s24-native-input-0 · 프로젝트 run과 독립된 원본 식별자
- 보존됨: experiment.json · artifact-82a64a68201940a04db980d1-3 · run s24-example-run-1
  schema pendulum-experiment/v1 · 1411 bytes · SHA-256 82a64a68201940a04db980d1429afc0685f0b2ca1025291d1a74ca1755ebe00f
  path artifacts/artifact-82a64a68201940a04db980d1-3.json · parents (없음)
  캡처한 canonical 설정. SI 값·단위·seed·적분·model/schema version을 보존합니다.
- 보존됨: series.json · artifact-b40bb718270dfc399ce7d2f1-4 · run s24-example-run-1
  schema pendulum-project-series/v1 · 5549 bytes · SHA-256 b40bb718270dfc399ce7d2f198ffa54a1e5c4ac919df2575398217446fd19222
  path artifacts/artifact-b40bb718270dfc399ce7d2f1-4.json · parents artifact-82a64a68201940a04db980d1-3
  실제 기록 표본을 순서·시간축·좌표·단위와 함께 복사했습니다. 보간·단위 재명명·재계산하지 않았습니다.
- 보존됨: energy-1.json · artifact-c252eec67e2a082b127c375b-5 · run s24-example-run-1
  schema pendulum-core-diagnostic/v1 · 9127 bytes · SHA-256 c252eec67e2a082b127c375b22f66bd730f5c97c0190a73540b245bf72b72e51
  path artifacts/artifact-c252eec67e2a082b127c375b-5.json · parents artifact-b40bb718270dfc399ce7d2f1-4
  보존한 원 기록에서 기존 native 에너지 분석을 실행했습니다. native input ID도 별도로 보존합니다.
  Native input s24-native-input-1 · 프로젝트 run과 독립된 원본 식별자

## Notebook

### 기록과 해석의 구분

기존 엔진의 두 run을 초기조건부터 종료시간까지 실행했습니다. 원본 표본과 설정·단위·적분기를 그대로 보존합니다. 그림은 재적분 없이 기록에서 생성하며 에너지 분석은 별도 native artifact입니다. 이 예시는 장기 발산률이나 카오스를 입증하지 않습니다. 생성 소스 commit: 3f1dcfb067c70fc63ad982abcf3d17bac647265b.

Artifact references: artifact-69d2a219ec924caf50dc5e67-0, artifact-9e34ca15fd690c68204f5d49-1, artifact-a4592ff6a9295abfd057726d-2, artifact-82a64a68201940a04db980d1-3, artifact-b40bb718270dfc399ce7d2f1-4, artifact-c252eec67e2a082b127c375b-5

## Figures

### 첫 각도 기록 1

21개 원본 기록 표본. 초기각 차이 0 rad, 관찰 0.2 s. 유한한 기록으로 카오스를 판정하지 않습니다.

Run s24-example-run-0 → artifact artifact-9e34ca15fd690c68204f5d49-1 → figure s24-example-figure-0. 축 -1, 0.
출력: figures/s24-example-figure-0.svg · figures/s24-example-figure-0.csv
그림 생성 시 축·표본·표시 한도를 다시 확인하며 실패 사유는 unavailable.txt에 기록합니다.

### 첫 각도 기록 2

21개 원본 기록 표본. 초기각 차이 0.001 rad, 관찰 0.2 s. 유한한 기록으로 카오스를 판정하지 않습니다.

Run s24-example-run-1 → artifact artifact-b40bb718270dfc399ce7d2f1-4 → figure s24-example-figure-1. 축 -1, 0.
출력: figures/s24-example-figure-1.svg · figures/s24-example-figure-1.csv
그림 생성 시 축·표본·표시 한도를 다시 확인하며 실패 사유는 unavailable.txt에 기록합니다.

## Citations

- Pendulum Lab preserved planar adapter and core energy diagnostics. Repository source accompanying this package. https://github.com/elliotjung/pendulum-lab

## Warnings

- 체크섬은 파일 무결성만 확인하며 원본의 진위·과학적 정확성·사람 검토를 인증하지 않습니다.
